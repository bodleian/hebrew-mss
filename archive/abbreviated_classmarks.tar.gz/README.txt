These files were removed from the 'collections' folder on 2018-01-31.

They are almost entirely identical to descriptions of the same manuscripts in files with names (and with classmarks) in which the collection name is not abbreviated. Random sampling found just a few punctuation marks and the xml:id attributes differ.

For example, MS_Can_Or_69.xml describes the same manuscript as MS_Canonici_Or_69.xml. It is just that, according to César Merchán-Hamann, it was decided some time ago that using classmarks such as 'MS. Canonici Or. 69' would make things easier to find than 'MS. Can Or. 69'.


